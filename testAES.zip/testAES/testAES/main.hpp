//
//  main.hpp
//  testAES
//
//  Created by 杨涛 on 2019/9/11.
//  Copyright © 2019 杨涛. All rights reserved.
//


#ifndef SimpleAesUtil_hpp
#define SimpleAesUtil_hpp

#include <stdio.h>
#include <string>
unsigned char *randomAESKey(void);
char * toEncrypt(char * data);
std::string toDecrypt(char * data);
#endif /* SimpleAesUtil_hpp */
