//
//  Base64.hpp
//  cPlusTranslator
//
//  Created by 杨涛 on 2019/9/7.
//  Copyright © 2019 杨涛. All rights reserved.
//

#ifndef Base64_hpp
#define Base64_hpp

#include <stdio.h>

#endif /* Base64_hpp */

#ifndef BASE64_H_C0CE2A47_D10E_42C9_A27C_C883944E704A
#define BASE64_H_C0CE2A47_D10E_42C9_A27C_C883944E704A

#include <string>

std::string base64_encode(unsigned char const* , unsigned int len);
std::string base64_decode(std::string const& s);

#endif /* BASE64_H_C0CE2A47_D10E_42C9_A27C_C883944E704A */
