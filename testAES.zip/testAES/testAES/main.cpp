//
//  SimpleAesUtil.cpp
//  cPlusTranslator
//
//  Created by 杨涛 on 2019/9/7.
//  Copyright © 2019 杨涛. All rights reserved.
//

#include "main.hpp"
#include "AES.h"
#include "string"
#include "Base64.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <MacTypes.h>
#include <iostream>
#include "Base64.hpp"
#include <iostream>
#include "AES.h"
#include "ND5.hpp"


using namespace std;

string  toEncrypt(char *data,CBm53AES aes){
    
    
    //     先进行 aes 加密，
    
    char jiami_values[1024]={0};
    
    aes.CipherStr(data,jiami_values);
    string  aes_encript(jiami_values);
    
    
    //base 64 加密
    std::string encoded = base64_encode(reinterpret_cast<const unsigned char*>(aes_encript.c_str()), (int)aes_encript.length());
    return encoded;
    
}

std::string toDecrypt(string  data,CBm53AES aes){
    
    //        先base64 解密
    std::string decoded = base64_decode(data);
    
    
    //    在aes 解密
    int i=0;
    char data_char[decoded.length()];
    for (i=0; i<decoded.length(); i++) {
        data_char[i]=decoded[i];
    }
    data_char[i]='\0';
    
    char  result[1024];
    
    aes.InvCipherStr(data_char, result);
    
    string output_data(result);
    
    return output_data.c_str();
}


unsigned char* randomAESKey(){
    
    std::string sb="";
    //    sb = (char *)malloc(sizeof(char)*16);
    int max1 = '+', min1 = '+', max2 = '/', min2 = '/', max3 = '9', min3 = '0', max4 = 'Z', min4 = 'A', max5 = 'z', min5 = 'a';
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 16; i++) {
        float num ;
        
        num=rand() % 10/10.0;
        
        int max;
        int min;
        if (num < 0.05) {
            max = max1;
            min = min1;
        } else if (num < 0.1) {
            max = max2;
            min = min2;
        } else if (num < 0.3) {
            max = max3;
            min = min3;
        } else if (num < 0.65) {
            max = max4;
            min = min4;
        } else {
            max = max5;
            min = min5;
        }
        int  n=max-min+1;
        num=rand() % n+ min;
        char c = (char) (num);
        
        sb=sb+c;
        
    }
    
    //放开可查看key 值
//    cout<<"key 值是："<<sb<<endl;
    unsigned char key_char[sb.length()];
    
    return key_char;
    
}



int main(int argc, const char * argv[]) {
    unsigned char *key = randomAESKey();
    char data[] = "我是小妖怪，逍遥又自在，杀人不眨眼，吃人不放盐";
    CBm53AES aes(key);
    
    
    string afterencrypt=toEncrypt(data,aes);
    cout<<"解密前的数据是：\n"<<afterencrypt<<endl;
    cout<<"解密后的数据是：\n"<<toDecrypt(afterencrypt,aes)<<endl;
    return 0;
}
